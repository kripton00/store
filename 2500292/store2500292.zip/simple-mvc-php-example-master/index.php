<?php

require_once "ddbb/DBConexion.php";
require_once "controllers/productsCtrl.php";